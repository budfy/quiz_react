import React, { useState } from "react";
import "./Resume.scss"
import imt from "../../img/dist/icon-imt.svg";
import age from "../../img/dist/icon-age.svg";
import calories from "../../img/dist/icon-calories.svg";
import water from "../../img/dist/icon-water.svg";
import weightLoss from "../../img/dist/icon-weight-loss.svg";
import weight from "../../img/dist/icon-weight.svg";

export default function Resume(props) {

  function nextStep() {
    let step = props.step;
    props.setStep(step + 1)
  }

  return (
    <div className="resume" id="resume">
      <div className="container">
        <div className="resume__wrap">
          <h1 className="resume__heading">Резюме вашего профиля</h1>
          <div className="resume__wrapper">
            <div className="resume__item">
              <h3 className="resume__title">Ваш ИМТ</h3>
              <picture className="resume__img">
                <span className="resume__amount">90,10</span>
                <img src={imt} alt="Image" />
              </picture>
              <span className="resume__value">Ожидание резкое</span>
            </div>
            <div className="resume__item">
              <h3 className="resume__title">Метаболический возраст</h3>
              <picture className="resume__img">
                <img src={age} alt="Image" />
              </picture>
              <span className="resume__value">34 года</span>
            </div>
            <div className="resume__item">
              <h3 className="resume__title">Рекомендуемое количество калорий</h3>
              <picture className="resume__img">
                <img src={calories} width="50px" height="50px" alt="Image" />
              </picture>
              <span className="resume__value">1833-1920</span>
            </div>
            <div className="resume__item">
              <h3 className="resume__title">Рекомендуемое количество воды</h3>
              <picture className="resume__img">
                <img src={water} width="62px" height="56px" alt="Image" />
              </picture>
              <span className="resume__value">3,5 литров</span>
            </div>
            <div className="resume__item">
              <h3 className="resume__title">Похудение в зонах</h3>
              <picture className="resume__img">
                <img src={weightLoss} alt="Image" />
              </picture>
            </div>
            <div className="resume__item">
              <h3 className="resume__title">Достижимый вес после 28 дней диеты</h3>
              <picture className="resume__img">
                <img src={weight} width="50px" height="50px" alt="Image" />
              </picture>
              <span className="resume__value">111 кг</span>
            </div>
          </div>
          <button className="resume__btn btn btn--green" onClick={nextStep}>Получить прямо сейчас</button>
        </div>
      </div>
    </div>
  )
}