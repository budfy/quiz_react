import React, { useState } from "react";
import validator from 'validator';
import "./Form.scss";

function Form(props) {

  function Email() {
    const [emailError, setEmailError] = useState('')
    const validateEmail = (e) => {
      var email = e.target.value

      if (validator.isEmail(email)) {
        setEmailError('')
      } else {
        setEmailError('Введите корректный Email!')
      }
    }

    return (
      <>
        <input type="text" id="userEmail" className="input poll-form__input" placeholder="Ваш Email"
          onChange={(e) => validateEmail(e)}></input> <br />
        {emailError ? <span style={{
          fontWeight: 'bold',
          color: '#EA2121',
          position: ''
        }}>{emailError}</span> : ""}
      </>
    );
  }


  return (
    <form className="poll-form">
      {/* <input type="email" className="input poll-form__input" maskPlaceholder="xxx@yyy.com" placeholder="Ваш Email" /> */}
      {Email()}
      <button className="poll-form__btn btn btn--green" type="button">Оплатить</button>
      <label htmlFor="poll-form" className="circle-checkbox poll-form__checkbox">
        <input type="checkbox" id="poll-form" className="circle-checkbox__input" />
        <span className="circle-checkbox__icon"></span>
        <span className="circle-checkbox__label">Нажимая кнопку "Оплатить" Вы даете согласие на обработку персональных данных, а также подтверждаете ознакомление с публичной офертойи тарифами</span>
        <picture>
          <source media="(min-width: )" srcset="" />
          <img src="" alt="" />
        </picture>
      </label>
    </form>
  )
}

export default Form;
